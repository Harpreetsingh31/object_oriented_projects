#ifndef DEFS_H
#define DEFS_H
#define MAX_PRODUCTS 54
#define MAX_COURSES  1024
#define MAX_BOOKS      32

#endif

